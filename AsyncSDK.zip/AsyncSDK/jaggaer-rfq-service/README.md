# jaggaer-rfq-service

JAGGAER &harr; PLM RFQ data-package service. Sprint 1 walking-skeleton PoC.

## What this is

A clean, modern Spring Boot 3.4 / Java 17 service implementing the two HTTP routes specified
in the *JAGGAER &harr; PLM Interface Technical Specification v1.0*:

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/cvsplmwebservices/sap/v1/kbCreateRfqDataPackage` | Async accept &mdash; returns 202 with a `requestId`. Background pipeline assembles the data package. |
| `GET`  | `/cvsplmwebservices/sap/v1/kbGetRfqDataPackage/{requestId}` | Sync retrieval. HTTP status conveys readiness (200 / 302 / 404 / 409 / 410). |
| `GET`  | `/cvsplmwebservices/sap/v1/healthCheck` | Liveness probe for SAP Integration Suite. |

This is a **deliberately fresh project**, not a fork of the existing `kb_middleware`
codebase. The two share a Teamcenter backend but their requirements and operational
profiles differ enough that copying legacy patterns into JAGGAER would do more harm
than good (singleton TC session, JJWT 0.9.1 lock-in, field injection, untyped configuration
holders). This service uses modern Spring Boot 3 patterns end to end.

## Sprint 1 scope

The background pipeline is **simulated** &mdash; no Teamcenter SOA calls are made. The
worker walks `ACCEPTED` &rarr; `IN_PROGRESS` (CVP &rarr; MASTER_DATA &rarr; FILES &rarr;
PACKAGE &rarr; UPLOAD) &rarr; `READY` on configurable delays. The 200 response returns a
stub ZIP containing a single README.txt; the 302 mode returns a placeholder Location header.

This is enough to:

- Prove the async dispatch + state machine + tracking-store mechanism end to end.
- Lock the HTTP contract (status code matrix, headers, idempotency) so SAP IS can build
  their iflow against it in parallel.
- Provide a regression test surface for sprints 2-4 (real CVP, real master-data, real
  package assembly, real upload).

Real Teamcenter integration arrives in subsequent sprints.

## Demo scenarios

| # | Action | Expected response |
|---|---|---|
| 1 | `POST` valid request | 202 with `requestId`, `downloadUrl`, `estimatedCompletion` |
| 2 | `POST` again with same `jaggaerRequestId` | 202 with the **same** `requestId` (idempotent) |
| 3 | `POST` with malformed body | 400 with code `TC-400-VAL` |
| 4 | `GET` immediately after POST | 409 with `state: ACCEPTED` and `Retry-After` header |
| 5 | `GET` mid-pipeline | 409 with `state: IN_PROGRESS` and `currentStep` |
| 6 | `GET` after worker completes | 200 with `application/zip` body and `X-Package-*` headers |
| 7 | `GET` with download-mode=REDIRECT | 302 with `Location` header |
| 8 | `GET` for unknown `requestId` | 404 with code `TC-404-REQ` |
| 9 | `POST` with `partId=FAIL_TEST` then `GET` | 410 with code `TC-404-CVP` and message "Part number not valid" |

## Build and deploy

The service is packaged as a **WAR** for deployment into an external Tomcat
(matching the Knorr-Bremse middleware deployment standard). The same WAR remains
runnable standalone in development.

```bash
# Run tests
mvn clean verify

# Dev mode (embedded Tomcat on port 8080)
mvn spring-boot:run

# Build the deployable WAR
mvn clean package
# produces: target/jaggaer-rfq-service.war
```

### Deploy to external Tomcat

Drop `target/jaggaer-rfq-service.war` into Tomcat's `webapps/` directory.
The application then becomes available at:

```
http://<host>:<port>/jaggaer-rfq-service/cvsplmwebservices/sap/v1/healthCheck
```

If you want the application mounted at the root context (no
`/jaggaer-rfq-service/` prefix), rename the deployed file to `ROOT.war` or
configure a Tomcat `<Context>` mapping accordingly.

### Run the WAR standalone (no external Tomcat)

Spring Boot WARs are dual-purpose. The same artifact can be executed with
embedded Tomcat:

```bash
java -jar target/jaggaer-rfq-service.war
```

## Try it (curl)

```bash
# Health
curl http://localhost:8080/cvsplmwebservices/sap/v1/healthCheck

# Submit
curl -X POST http://localhost:8080/cvsplmwebservices/sap/v1/kbCreateRfqDataPackage \
  -H "Content-Type: application/json" \
  -d '{"jaggaerRequestId":"REQ-DEMO-001","requestorId":"u","partId":"K211977","systemContext":"TRUCK"}'

# Poll the returned requestId
curl -i http://localhost:8080/cvsplmwebservices/sap/v1/kbGetRfqDataPackage/tc-XXXXXXXX

# Trigger a FAILED outcome
curl -X POST http://localhost:8080/cvsplmwebservices/sap/v1/kbCreateRfqDataPackage \
  -H "Content-Type: application/json" \
  -d '{"jaggaerRequestId":"REQ-DEMO-FAIL","requestorId":"u","partId":"FAIL_TEST","systemContext":"TRUCK"}'
```

## API documentation

Swagger UI is mounted at `http://localhost:8080/swagger-ui.html` once the service is running.
The OpenAPI 3 spec itself is at `/v3/api-docs`.

## Configuration

All settings are namespaced under `jaggaer.*`. See `src/main/resources/application.properties`
for defaults. The simulator step delays are configurable so the same code is used for
demo (visible state transitions over ~12s) and tests (zero delay for synchronous-style
assertions).

## What's intentionally *not* here

- **No Teamcenter SOA jars.** The background pipeline is a stub. Sprint 2 introduces
  the `CvpResolver`, `MasterDataCollector`, `FileCollector`, and a per-worker
  TC session pool running under the Generic Purchasing Account.
- **No PI Portal upload.** The 200 response returns a stub ZIP; the 302 mode points at a
  placeholder URL. Real upload is wired in Sprint 4 once the SAP IS contract is finalised.
- **No authentication.** Sprint 2 adds Spring Security OAuth2 Resource Server with the
  service-account token issued by SAP Integration Suite.
- **No persistent tracking store.** Sprint 1 uses an in-memory `ConcurrentHashMap`.
  Sprint 2 swaps in a Teamcenter business object or JPA-backed implementation behind the
  unchanged `TrackingStore` interface.

## Project layout

```
src/main/java/com/kbmiddleware/jaggaer/
  JaggaerRfqApplication.java          Main entry point
  controller/JaggaerRfqController.java    POST + GET + healthCheck
  api/...                              Wire-format DTOs (records)
  domain/...                           Internal model (RfqState, ErrorCode, TrackingEntry)
  tracking/...                         TrackingStore interface + InMemory impl
  async/BackgroundWorkerSimulator.java Stub pipeline (sprint 1 only)
  config/...                           JaggaerProperties, AsyncConfig, OpenApiConfig
  exception/...                        Exception handler + RfqNotFoundException
```

package com.kbmiddleware.jaggaer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * Entry point for the JAGGAER RFQ data-package service.
 *
 * <p>The service ships as a WAR for deployment into an external servlet container
 * (Tomcat / Knorr-Bremse standard) but remains runnable standalone in development:
 *
 * <pre>
 *   mvn spring-boot:run                  # dev mode, embedded Tomcat
 *   mvn clean package                    # produces target/jaggaer-rfq-service.war
 *   # then drop the WAR into Tomcat's webapps directory
 * </pre>
 *
 * <p>Extending {@link SpringBootServletInitializer} and overriding
 * {@link #configure(SpringApplicationBuilder)} is the Spring Boot pattern for picking
 * the application up via the servlet container's {@code ServletContainerInitializer}
 * mechanism when the WAR is deployed externally.
 */
@SpringBootApplication
public class JaggaerRfqApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(JaggaerRfqApplication.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(JaggaerRfqApplication.class);
    }
}

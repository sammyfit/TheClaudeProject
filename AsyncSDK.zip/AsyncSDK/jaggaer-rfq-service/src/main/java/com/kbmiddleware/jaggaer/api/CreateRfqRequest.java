package com.kbmiddleware.jaggaer.api;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

/**
 * POST request body for {@code kbCreateRfqDataPackage} (spec &sect;11.2.1).
 *
 * <p>{@code rfqNumber}, {@code rfqVersion}, and {@code rfqItemPosition} are accepted
 * optionally so the contract is forward-compatible with the real package header
 * (sample {@code bomData.package} object).
 */
public record CreateRfqRequest(

        @NotBlank(message = "jaggaerRequestId is required")
        @Pattern(regexp = "^[A-Za-z0-9._\\-]{1,128}$",
                 message = "jaggaerRequestId must be 1-128 chars of [A-Za-z0-9._-]")
        String jaggaerRequestId,

        @NotBlank(message = "requestorId is required")
        String requestorId,

        @NotBlank(message = "partId is required")
        String partId,

        @NotNull(message = "systemContext is required")
        SystemContext systemContext,

        SelectionMode selectionMode,
        Scope scope,
        Boolean includeJt,
        Boolean applyStamp,

        String rfqNumber,
        Integer rfqVersion,
        Integer rfqItemPosition
) {

    public SelectionMode selectionModeOrDefault() {
        return selectionMode == null ? SelectionMode.LATEST_RELEASED : selectionMode;
    }

    public Scope scopeOrDefault() {
        return scope == null ? Scope.FULL : scope;
    }

    public boolean includeJtOrDefault() {
        return Boolean.TRUE.equals(includeJt);
    }

    public boolean applyStampOrDefault() {
        return Boolean.TRUE.equals(applyStamp);
    }
}

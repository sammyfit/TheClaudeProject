package com.kbmiddleware.jaggaer.api;

import com.kbmiddleware.jaggaer.domain.RfqState;

import java.time.Instant;

/**
 * 202 Accepted response body for {@code kbCreateRfqDataPackage} (spec &sect;11.2.2).
 */
public record CreateRfqResponse(
        String   requestId,
        String   jaggaerRequestId,
        RfqState status,
        String   downloadUrl,
        Instant  estimatedCompletion
) {}

package com.kbmiddleware.jaggaer.api;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.kbmiddleware.jaggaer.domain.CurrentStep;
import com.kbmiddleware.jaggaer.domain.RfqState;

import java.time.Instant;

/**
 * 409 Conflict response body returned by the GET endpoint while the underlying request
 * is in {@link RfqState#ACCEPTED} or {@link RfqState#IN_PROGRESS} (spec &sect;11.3.4).
 *
 * <p>Companion {@code Retry-After} header carries the suggested polling delay in seconds.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record PackageProgress(
        String      requestId,
        String      jaggaerRequestId,
        RfqState    state,
        CurrentStep currentStep,
        Instant     estimatedCompletion
) {}

package com.kbmiddleware.jaggaer.api;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.kbmiddleware.jaggaer.domain.RfqState;

import java.time.Instant;

/**
 * 410 Gone response body returned by the GET endpoint when the underlying request has
 * entered {@link RfqState#FAILED} or {@link RfqState#EXPIRED} (spec &sect;11.3.5).
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record RfqErrorResponse(
        String   requestId,
        String   jaggaerRequestId,
        RfqState state,
        Error    error,
        Instant  expiredAt
) {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record Error(String code, String message, String details) {}
}

package com.kbmiddleware.jaggaer.api;

/**
 * Progressive-enrichment scope (spec &sect;13.2.3).
 * <ul>
 *   <li>{@link #BASIC} &mdash; first-pass minimal master data so JAGGAER can decide what else is needed.</li>
 *   <li>{@link #FULL}  &mdash; second-pass complete payload (default).</li>
 * </ul>
 */
public enum Scope {
    BASIC,
    FULL
}

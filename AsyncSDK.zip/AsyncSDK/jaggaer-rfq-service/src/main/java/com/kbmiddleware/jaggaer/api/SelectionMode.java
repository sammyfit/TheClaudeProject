package com.kbmiddleware.jaggaer.api;

/**
 * Revision-selection preference supplied by JAGGAER. Per spec &sect;13.1.3, when the
 * requested category does not match the canonical CVP outcome, the service falls back
 * to the latest Released and surfaces a non-fatal warning.
 */
public enum SelectionMode {
    LATEST_RELEASED,
    LATEST_APPROVED
}

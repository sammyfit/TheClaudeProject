package com.kbmiddleware.jaggaer.api;

/**
 * PLM routing target supplied by JAGGAER. Per spec &sect;11.2.1 the request is routed
 * to the corresponding system (Truck or Rail) before reaching Teamcenter; the value is
 * carried for audit and correlation.
 */
public enum SystemContext {
    TRUCK,
    RAIL
}

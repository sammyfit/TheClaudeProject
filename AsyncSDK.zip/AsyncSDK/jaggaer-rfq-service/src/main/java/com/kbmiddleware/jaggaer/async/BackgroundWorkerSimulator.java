package com.kbmiddleware.jaggaer.async;

import com.kbmiddleware.jaggaer.config.AsyncConfig;
import com.kbmiddleware.jaggaer.config.JaggaerProperties;
import com.kbmiddleware.jaggaer.domain.CurrentStep;
import com.kbmiddleware.jaggaer.domain.ErrorCode;
import com.kbmiddleware.jaggaer.domain.TrackingEntry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.Duration;

/**
 * Sprint 1 stand-in for the real four-step pipeline.
 *
 * <p>Walks the {@link TrackingEntry} through CVP &rarr; MASTER_DATA &rarr; FILES &rarr;
 * PACKAGE &rarr; UPLOAD on configured delays, then marks the entry READY. No Teamcenter
 * SOA calls, no FMS, no PI Portal upload.
 *
 * <p><b>Failure path</b>: if {@link com.kbmiddleware.jaggaer.api.CreateRfqRequest#partId()}
 * matches {@link JaggaerProperties.Simulator#failTriggerPartId()} (default {@code FAIL_TEST}),
 * the worker fails on the CVP step with {@link ErrorCode#TC_404_CVP} and the canonical
 * JAGGAER-facing message <em>"Part number not valid"</em>. This exercises the 410 Gone
 * response path during demos without needing real Teamcenter data.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class BackgroundWorkerSimulator {

    private final JaggaerProperties properties;

    @Async(AsyncConfig.JAGGAER_EXECUTOR)
    public void start(TrackingEntry entry) {
        String correlation = correlation(entry);
        log.info("{} background worker started", correlation);

        try {
            JaggaerProperties.Simulator sim = properties.simulator();
            String triggerId = sim.failTriggerPartId();

            // Demo / regression hook: fail-trigger Part ID short-circuits to FAILED.
            if (triggerId != null && triggerId.equalsIgnoreCase(entry.getRequest().partId())) {
                stage(entry, CurrentStep.CVP, sim.cvpDelay());
                entry.markFailed(
                        ErrorCode.TC_404_CVP,
                        "Part number not valid",
                        "Simulated CVP failure triggered by partId=" + entry.getRequest().partId()
                );
                log.warn("{} simulated FAILED outcome on CVP step", correlation);
                return;
            }

            stage(entry, CurrentStep.CVP,         sim.cvpDelay());
            stage(entry, CurrentStep.MASTER_DATA, sim.masterDataDelay());
            stage(entry, CurrentStep.FILES,       sim.filesDelay());
            stage(entry, CurrentStep.PACKAGE,     sim.packageDelay());
            stage(entry, CurrentStep.UPLOAD,      sim.uploadDelay());

            entry.markReady();
            log.info("{} background worker completed; state=READY", correlation);

        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            entry.markFailed(ErrorCode.TC_500_INT, "Worker interrupted", ie.getMessage());
            log.warn("{} background worker interrupted", correlation);
        } catch (RuntimeException e) {
            entry.markFailed(ErrorCode.TC_500_INT, "Internal error", e.getMessage());
            log.error("{} background worker failed unexpectedly", correlation, e);
        }
    }

    private void stage(TrackingEntry entry, CurrentStep step, Duration delay) throws InterruptedException {
        entry.markInProgress(step);
        log.debug("{} entered step={} delay={}", correlation(entry), step, delay);
        long ms = Math.max(0L, delay.toMillis());
        if (ms > 0) {
            Thread.sleep(ms);
        }
    }

    private static String correlation(TrackingEntry entry) {
        return "[req=" + entry.getRequestId() + " jaggaer=" + entry.getJaggaerRequestId() + "]";
    }
}

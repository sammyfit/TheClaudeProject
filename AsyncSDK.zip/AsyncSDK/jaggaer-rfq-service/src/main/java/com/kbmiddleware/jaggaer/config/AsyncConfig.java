package com.kbmiddleware.jaggaer.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Activates {@code @Async} for the JAGGAER service and exposes a dedicated
 * {@link Executor} bean.
 *
 * <p>The executor is intentionally <b>not</b> the Spring default. Sharing the default
 * executor with future scheduled or async work would couple back-pressure across
 * unrelated features. Keeping JAGGAER on its own pool gives clean operational isolation.
 */
@Slf4j
@Configuration
@EnableAsync
@EnableConfigurationProperties(JaggaerProperties.class)
@RequiredArgsConstructor
public class AsyncConfig {

    public static final String JAGGAER_EXECUTOR = "jaggaerTaskExecutor";

    private final JaggaerProperties properties;

    @Bean(name = JAGGAER_EXECUTOR)
    public Executor jaggaerTaskExecutor() {
        JaggaerProperties.Async cfg = properties.async();

        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(cfg.corePoolSize());
        executor.setMaxPoolSize(cfg.maxPoolSize());
        executor.setQueueCapacity(cfg.queueCapacity());
        executor.setThreadNamePrefix(cfg.threadNamePrefix());
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(30);
        executor.initialize();

        log.info("JAGGAER async executor initialised: core={} max={} queue={} prefix='{}'",
                cfg.corePoolSize(), cfg.maxPoolSize(), cfg.queueCapacity(), cfg.threadNamePrefix());
        return executor;
    }
}

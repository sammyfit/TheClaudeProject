package com.kbmiddleware.jaggaer.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.validation.annotation.Validated;

import java.time.Duration;

/**
 * Typed configuration for the JAGGAER service. All settings are namespaced under
 * {@code jaggaer.*}.
 *
 * <p>The simulator delays govern how long the stub background worker spends on each
 * step. Setting them to {@code PT0S} in test profiles yields synchronous-style behaviour
 * suitable for assertions.
 */
@Validated
@ConfigurationProperties(prefix = "jaggaer")
public record JaggaerProperties(

        @DefaultValue("BINARY")
        DownloadMode downloadMode,

        @DefaultValue("https://pi-portal.example.local/jaggaer/staging")
        String redirectBaseUrl,

        @Valid @DefaultValue
        Simulator simulator,

        @Valid @DefaultValue
        Async async,

        @Valid @DefaultValue
        Retention retention
) {

    /** Governs the GET endpoint's response style when the package is READY (spec &sect;11.3.3). */
    public enum DownloadMode { BINARY, REDIRECT }

    public record Simulator(
            @NotNull @DefaultValue("PT2S") Duration cvpDelay,
            @NotNull @DefaultValue("PT3S") Duration masterDataDelay,
            @NotNull @DefaultValue("PT3S") Duration filesDelay,
            @NotNull @DefaultValue("PT2S") Duration packageDelay,
            @NotNull @DefaultValue("PT2S") Duration uploadDelay,
                     @DefaultValue("FAIL_TEST") String failTriggerPartId
    ) {
        /** Sum of all step delays &mdash; used to compute {@code estimatedCompletion}. */
        public Duration totalDelay() {
            return cvpDelay
                    .plus(masterDataDelay)
                    .plus(filesDelay)
                    .plus(packageDelay)
                    .plus(uploadDelay);
        }
    }

    public record Async(
            @Positive @DefaultValue("4")  int    corePoolSize,
            @Positive @DefaultValue("8")  int    maxPoolSize,
            @Positive @DefaultValue("32") int    queueCapacity,
                      @DefaultValue("jaggaer-worker-") String threadNamePrefix
    ) {}

    public record Retention(
            @NotNull @DefaultValue("PT1H") Duration packageRetention
    ) {}
}

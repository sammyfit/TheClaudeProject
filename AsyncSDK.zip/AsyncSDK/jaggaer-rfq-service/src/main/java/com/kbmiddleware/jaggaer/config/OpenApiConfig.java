package com.kbmiddleware.jaggaer.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * OpenAPI 3 metadata. Swagger UI is mounted at {@code /swagger-ui.html}; the spec is
 * served from {@code /v3/api-docs}. The SAP Integration Suite team can use this to
 * scaffold their iflow against the contract during integration.
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI jaggaerRfqOpenApi() {
        return new OpenAPI().info(new Info()
                .title("JAGGAER <-> PLM RFQ Data-Package Service")
                .description("""
                        Two SOA-style HTTP routes for the JAGGAER integration plus a health-check probe.

                        Sprint 1 PoC: the background pipeline is simulated with static data. State transitions
                        from ACCEPTED -> IN_PROGRESS -> READY happen on configurable delays. POST with
                        partId=FAIL_TEST short-circuits to a FAILED outcome on the CVP step.
                        """)
                .version("0.1.0")
                .contact(new Contact().name("CVS PLM Team"))
                .license(new License().name("Knorr-Bremse Internal")));
    }
}

package com.kbmiddleware.jaggaer.controller;

import com.kbmiddleware.jaggaer.api.CreateRfqRequest;
import com.kbmiddleware.jaggaer.api.CreateRfqResponse;
import com.kbmiddleware.jaggaer.api.PackageProgress;
import com.kbmiddleware.jaggaer.api.RfqErrorResponse;
import com.kbmiddleware.jaggaer.async.BackgroundWorkerSimulator;
import com.kbmiddleware.jaggaer.config.JaggaerProperties;
import com.kbmiddleware.jaggaer.domain.RfqState;
import com.kbmiddleware.jaggaer.domain.TrackingEntry;
import com.kbmiddleware.jaggaer.exception.RfqNotFoundException;
import com.kbmiddleware.jaggaer.tracking.TrackingStore;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * JAGGAER RFQ data-package endpoints (spec &sect;11).
 */
@Slf4j
@RestController
@RequestMapping("cvsplmwebservices/sap/v1")
@RequiredArgsConstructor
public class JaggaerRfqController {

    private static final String HDR_REQUEST_ID         = "X-Package-Request-Id";
    private static final String HDR_JAGGAER_REQUEST_ID = "X-Package-Jaggaer-Request-Id";
    private static final String HDR_SPLIT_COUNT        = "X-Package-Split-Count";
    private static final String HDR_PART_INDEX         = "X-Package-Part-Index";
    private static final String HDR_FILE_COUNT         = "X-Package-File-Count";
    private static final String HDR_MISSING_FILE_COUNT = "X-Package-Missing-File-Count";

    private static final DateTimeFormatter ZIP_TIMESTAMP =
            DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").withZone(ZoneOffset.UTC);

    private final TrackingStore             trackingStore;
    private final BackgroundWorkerSimulator worker;
    private final JaggaerProperties         properties;

    // -----------------------------------------------------------------------
    //  Health check
    // -----------------------------------------------------------------------

    @GetMapping("/healthCheck")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("status", "UP");
        body.put("service", "jaggaer-rfq-service");
        body.put("trackedRequests", trackingStore.size());
        body.put("downloadMode", properties.downloadMode());
        body.put("timestamp", Instant.now().toString());
        return ResponseEntity.ok(body);
    }

    // -----------------------------------------------------------------------
    //  POST kbCreateRfqDataPackage  (async accept)
    // -----------------------------------------------------------------------

    @PostMapping(value = "/kbCreateRfqDataPackage",
                 consumes = MediaType.APPLICATION_JSON_VALUE,
                 produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CreateRfqResponse> create(@Valid @RequestBody CreateRfqRequest request,
                                                    HttpServletRequest http) {
        log.info("POST kbCreateRfqDataPackage jaggaerRequestId={} partId={} systemContext={}",
                request.jaggaerRequestId(), request.partId(), request.systemContext());

        Instant eta = Instant.now().plus(properties.simulator().totalDelay());

        TrackingStore.StoreResult result = trackingStore.createOrGet(
                request.jaggaerRequestId(),
                () -> new TrackingEntry(generateRequestId(), request, eta)
        );

        TrackingEntry entry = result.entry();
        if (result.created()) {
            worker.start(entry);
        }

        CreateRfqResponse body = new CreateRfqResponse(
                entry.getRequestId(),
                entry.getJaggaerRequestId(),
                RfqState.ACCEPTED,
                buildDownloadUrl(http, entry.getRequestId()),
                entry.getEstimatedCompletion()
        );
        return ResponseEntity.accepted().body(body);
    }

    // -----------------------------------------------------------------------
    //  GET kbGetRfqDataPackage/{requestId}  (sync retrieval)
    // -----------------------------------------------------------------------

    @GetMapping("/kbGetRfqDataPackage/{requestId}")
    public ResponseEntity<?> get(@PathVariable("requestId") String requestId,
                                 @RequestParam(value = "part", required = false, defaultValue = "1") int part) {
        log.debug("GET kbGetRfqDataPackage requestId={} part={}", requestId, part);

        TrackingEntry entry = trackingStore.findByRequestId(requestId)
                .orElseThrow(() -> new RfqNotFoundException(requestId));

        return switch (entry.getState()) {
            case ACCEPTED, IN_PROGRESS -> respondNotReady(entry);
            case READY                 -> respondReady(entry, part);
            case FAILED, EXPIRED       -> respondGone(entry);
        };
    }

    // -----------------------------------------------------------------------
    //  Response builders
    // -----------------------------------------------------------------------

    private ResponseEntity<PackageProgress> respondNotReady(TrackingEntry entry) {
        PackageProgress body = new PackageProgress(
                entry.getRequestId(),
                entry.getJaggaerRequestId(),
                entry.getState(),
                entry.getCurrentStep(),
                entry.getEstimatedCompletion()
        );
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .header(HttpHeaders.RETRY_AFTER, String.valueOf(computeRetryAfterSeconds(entry)))
                .body(body);
    }

    private ResponseEntity<?> respondReady(TrackingEntry entry, int part) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HDR_REQUEST_ID,         entry.getRequestId());
        headers.add(HDR_JAGGAER_REQUEST_ID, entry.getJaggaerRequestId());
        headers.add(HDR_SPLIT_COUNT,        "1");
        headers.add(HDR_PART_INDEX,         String.valueOf(Math.max(1, part)));
        headers.add(HDR_FILE_COUNT,         "0");
        headers.add(HDR_MISSING_FILE_COUNT, "0");

        if (properties.downloadMode() == JaggaerProperties.DownloadMode.REDIRECT) {
            URI location = URI.create(
                    properties.redirectBaseUrl() + "/" + entry.getRequestId() + ".zip");
            return ResponseEntity.status(HttpStatus.FOUND)
                    .headers(headers)
                    .location(location)
                    .build();
        }

        byte[] zip = buildStubZip(entry);
        String filename = entry.getJaggaerRequestId() + "_" + ZIP_TIMESTAMP.format(entry.getReadyAt()) + ".zip";

        headers.setContentType(MediaType.parseMediaType("application/zip"));
        headers.setContentLength(zip.length);
        headers.setContentDisposition(ContentDisposition.attachment().filename(filename).build());

        return ResponseEntity.ok().headers(headers).body(zip);
    }

    private ResponseEntity<RfqErrorResponse> respondGone(TrackingEntry entry) {
        RfqErrorResponse.Error err = entry.getErrorCode() == null
                ? null
                : new RfqErrorResponse.Error(
                        entry.getErrorCode().code(),
                        entry.getErrorMessage(),
                        entry.getErrorDetails());

        RfqErrorResponse body = new RfqErrorResponse(
                entry.getRequestId(),
                entry.getJaggaerRequestId(),
                entry.getState(),
                err,
                entry.getExpiredAt()
        );
        return ResponseEntity.status(HttpStatus.GONE).body(body);
    }

    // -----------------------------------------------------------------------
    //  Helpers
    // -----------------------------------------------------------------------

    private long computeRetryAfterSeconds(TrackingEntry entry) {
        Duration remaining = Duration.between(Instant.now(), entry.getEstimatedCompletion());
        long seconds = remaining.isNegative() ? 2 : Math.max(2, remaining.dividedBy(2).toSeconds());
        return Math.min(seconds, 30);
    }

    private byte[] buildStubZip(TrackingEntry entry) {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             ZipOutputStream zos = new ZipOutputStream(baos)) {

            zos.putNextEntry(new ZipEntry("README.txt"));
            String content = """
                    Sprint 1 PoC stub package.

                    requestId        : %s
                    jaggaerRequestId : %s
                    partId           : %s
                    systemContext    : %s
                    requestor        : %s
                    createdAt        : %s
                    readyAt          : %s

                    NOTE: real index.html viewer + Files/ folder + ZIP split logic
                    arrive in Sprint 3 / Sprint 4 once the PackageAssembler is wired
                    to the real MasterDataCollector and FileCollector.
                    """.formatted(
                            entry.getRequestId(),
                            entry.getJaggaerRequestId(),
                            entry.getRequest().partId(),
                            entry.getRequest().systemContext(),
                            entry.getRequest().requestorId(),
                            entry.getCreatedAt(),
                            entry.getReadyAt()
                    );
            zos.write(content.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();
            zos.finish();
            return baos.toByteArray();

        } catch (IOException e) {
            throw new IllegalStateException("Failed to assemble stub ZIP for " + entry.getRequestId(), e);
        }
    }

    private static String buildDownloadUrl(HttpServletRequest http, String requestId) {
        StringBuilder url = new StringBuilder()
                .append(http.getScheme()).append("://")
                .append(http.getServerName());
        int port = http.getServerPort();
        if (port != 80 && port != 443) {
            url.append(':').append(port);
        }
        return url.append(http.getContextPath())
                .append("/cvsplmwebservices/sap/v1/kbGetRfqDataPackage/")
                .append(requestId)
                .toString();
    }

    private static String generateRequestId() {
        return "tc-" + UUID.randomUUID().toString().substring(0, 8);
    }
}

package com.kbmiddleware.jaggaer.domain;

/**
 * Granular progress indicator surfaced inside the 409 Conflict response body while a
 * request is {@link RfqState#IN_PROGRESS}. Mirrors the four-step business pipeline plus
 * the post-assembly upload (spec &sect;11.3.4).
 */
public enum CurrentStep {
    /** Determining the Current Valid Part (spec &sect;13.1). */
    CVP,
    /** Collecting Part / BoM / Document metadata (spec &sect;13.2). */
    MASTER_DATA,
    /** Retrieving presentation files via FMS (spec &sect;13.3). */
    FILES,
    /** Composing the index file and the ZIP (spec &sect;13.4). */
    PACKAGE,
    /** Uploading the ZIP to the SAP IS / PI Portal staging area (spec &sect;6.3.5). */
    UPLOAD
}

package com.kbmiddleware.jaggaer.domain;

/**
 * Canonical error taxonomy for the JAGGAER RFQ services (spec &sect;8.1.1).
 *
 * <p>The wire-format string is the dashed form (e.g. {@code TC-404-CVP}) returned in
 * 410 Gone error bodies and 400 / 404 / 500 short responses.
 */
public enum ErrorCode {

    TC_400_VAL      ("TC-400-VAL",      "Validation"),
    TC_401_AUTH     ("TC-401-AUTH",     "Security"),
    TC_404_CVP      ("TC-404-CVP",      "Business"),
    TC_404_REQ      ("TC-404-REQ",      "Request"),
    TC_409_STATE    ("TC-409-STATE",    "Business"),
    TC_409_NOT_READY("TC-409-NOT_READY","Flow"),
    TC_410_GONE     ("TC-410-GONE",     "Flow"),
    TC_413_SIZE     ("TC-413-SIZE",     "Packaging"),
    TC_424_FILE     ("TC-424-FILE",     "Data"),
    TC_502_UPLOAD   ("TC-502-UPLOAD",   "Integration"),
    TC_500_INT      ("TC-500-INT",      "Internal"),
    TC_503_DOWN     ("TC-503-DOWN",     "Availability");

    private final String code;
    private final String category;

    ErrorCode(String code, String category) {
        this.code = code;
        this.category = category;
    }

    public String code()     { return code; }
    public String category() { return category; }
}

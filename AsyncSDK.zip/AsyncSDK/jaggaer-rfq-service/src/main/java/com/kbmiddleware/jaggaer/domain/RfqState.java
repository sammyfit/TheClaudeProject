package com.kbmiddleware.jaggaer.domain;

/**
 * Lifecycle state of an RFQ data-package request (spec &sect;11.2.3).
 *
 * <p>The state surfaces to callers only through the HTTP status code returned by the
 * GET endpoint:
 *
 * <table>
 *   <tr><th>State</th><th>GET status</th></tr>
 *   <tr><td>{@link #ACCEPTED}</td><td>409 Conflict</td></tr>
 *   <tr><td>{@link #IN_PROGRESS}</td><td>409 Conflict</td></tr>
 *   <tr><td>{@link #READY}</td><td>200 OK (binary) or 302 Found (redirect)</td></tr>
 *   <tr><td>{@link #FAILED}</td><td>410 Gone</td></tr>
 *   <tr><td>{@link #EXPIRED}</td><td>410 Gone</td></tr>
 * </table>
 */
public enum RfqState {
    ACCEPTED,
    IN_PROGRESS,
    READY,
    FAILED,
    EXPIRED
}

package com.kbmiddleware.jaggaer.domain;

import com.kbmiddleware.jaggaer.api.CreateRfqRequest;
import lombok.Getter;

import java.time.Instant;

/**
 * In-memory record of one RFQ request tracked through its async lifecycle.
 *
 * <p>State transitions are guarded by {@code synchronized} on the entry instance.
 * The {@link com.kbmiddleware.jaggaer.tracking.TrackingStore} provides atomic
 * create-or-get semantics keyed on {@link CreateRfqRequest#jaggaerRequestId()} so that
 * duplicate POSTs cannot produce two entries.
 */
@Getter
public class TrackingEntry {

    private final String           requestId;
    private final String           jaggaerRequestId;
    private final CreateRfqRequest request;
    private final Instant          createdAt;
    private final Instant          estimatedCompletion;

    private volatile RfqState    state;
    private volatile CurrentStep currentStep;
    private volatile Instant     readyAt;
    private volatile Instant     expiredAt;
    private volatile ErrorCode   errorCode;
    private volatile String      errorMessage;
    private volatile String      errorDetails;

    public TrackingEntry(String requestId, CreateRfqRequest request, Instant estimatedCompletion) {
        this.requestId           = requestId;
        this.jaggaerRequestId    = request.jaggaerRequestId();
        this.request             = request;
        this.createdAt           = Instant.now();
        this.estimatedCompletion = estimatedCompletion;
        this.state               = RfqState.ACCEPTED;
    }

    public synchronized void markInProgress(CurrentStep step) {
        ensureNotTerminal();
        this.state       = RfqState.IN_PROGRESS;
        this.currentStep = step;
    }

    public synchronized void markReady() {
        ensureNotTerminal();
        this.state       = RfqState.READY;
        this.currentStep = null;
        this.readyAt     = Instant.now();
    }

    public synchronized void markFailed(ErrorCode code, String message, String details) {
        if (this.state == RfqState.READY) {
            // Refuse to overwrite a successful terminal state.
            return;
        }
        this.state        = RfqState.FAILED;
        this.currentStep  = null;
        this.errorCode    = code;
        this.errorMessage = message;
        this.errorDetails = details;
    }

    public synchronized void markExpired() {
        if (this.state == RfqState.READY) {
            this.state     = RfqState.EXPIRED;
            this.expiredAt = Instant.now();
        }
    }

    public synchronized boolean isTerminal() {
        return state == RfqState.READY || state == RfqState.FAILED || state == RfqState.EXPIRED;
    }

    private void ensureNotTerminal() {
        if (isTerminal()) {
            throw new IllegalStateException(
                "Cannot transition from terminal state " + state + " for request " + requestId);
        }
    }
}

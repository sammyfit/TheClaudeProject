package com.kbmiddleware.jaggaer.exception;

import com.kbmiddleware.jaggaer.domain.ErrorCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Maps controller exceptions to wire-format error responses keyed on the canonical
 * {@link ErrorCode} taxonomy.
 */
@Slf4j
@RestControllerAdvice
public class GlobalRfqExceptionHandler {

    @ExceptionHandler(RfqNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFound(RfqNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error(
                ex.getErrorCode(),
                ex.getMessage(),
                Map.of("requestId", ex.getRequestId())
        ));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidation(MethodArgumentNotValidException ex) {
        String details = ex.getBindingResult().getFieldErrors().stream()
                .map(fe -> fe.getField() + ": " + fe.getDefaultMessage())
                .collect(Collectors.joining("; "));
        return ResponseEntity.badRequest().body(error(
                ErrorCode.TC_400_VAL,
                "Validation failed",
                Map.of("details", details)
        ));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, Object>> handleMalformed(HttpMessageNotReadableException ex) {
        String detail = ex.getMostSpecificCause() == null
                ? ex.getMessage()
                : ex.getMostSpecificCause().getMessage();
        return ResponseEntity.badRequest().body(error(
                ErrorCode.TC_400_VAL,
                "Malformed request body",
                Map.of("details", detail == null ? "" : detail)
        ));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> handleIllegalArg(IllegalArgumentException ex) {
        return ResponseEntity.badRequest().body(error(
                ErrorCode.TC_400_VAL,
                "Invalid argument",
                Map.of("details", ex.getMessage() == null ? "" : ex.getMessage())
        ));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGeneric(Exception ex) {
        log.error("Unhandled exception", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error(
                ErrorCode.TC_500_INT,
                "Internal server error",
                Map.of()
        ));
    }

    private static Map<String, Object> error(ErrorCode code, String message, Map<String, ?> extras) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("code", code.code());
        body.put("message", message);
        if (extras != null) {
            extras.forEach(body::put);
        }
        return body;
    }
}

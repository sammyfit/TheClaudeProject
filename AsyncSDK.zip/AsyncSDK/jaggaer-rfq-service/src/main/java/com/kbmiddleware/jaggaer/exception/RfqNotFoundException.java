package com.kbmiddleware.jaggaer.exception;

import com.kbmiddleware.jaggaer.domain.ErrorCode;
import lombok.Getter;

/**
 * Thrown by the GET endpoint when the supplied {@code requestId} is unknown to the
 * tracking store. Mapped to HTTP 404 with code {@link ErrorCode#TC_404_REQ}.
 */
@Getter
public class RfqNotFoundException extends RuntimeException {

    private final ErrorCode errorCode = ErrorCode.TC_404_REQ;
    private final String    requestId;

    public RfqNotFoundException(String requestId) {
        super("Request ID not found: " + requestId);
        this.requestId = requestId;
    }
}

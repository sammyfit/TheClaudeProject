/**
 * JAGGAER &harr; PLM RFQ data-package service.
 *
 * <p>Three HTTP routes under {@code /cvsplmwebservices/sap/v1/}:
 *
 * <ul>
 *   <li>{@code POST /kbCreateRfqDataPackage} &mdash; async accept (HTTP 202).</li>
 *   <li>{@code GET  /kbGetRfqDataPackage/{requestId}} &mdash; sync retrieval; HTTP status
 *       conveys readiness (200 / 302 / 404 / 409 / 410).</li>
 *   <li>{@code GET  /healthCheck} &mdash; liveness probe.</li>
 * </ul>
 *
 * <p><b>Sprint 1 scope</b>: walking-skeleton PoC. The background pipeline is simulated
 * by {@link com.kbmiddleware.jaggaer.async.BackgroundWorkerSimulator} which transitions
 * tracking state through CVP &rarr; MASTER_DATA &rarr; FILES &rarr; PACKAGE &rarr; UPLOAD on
 * configurable delays. Real Teamcenter SOA integration arrives in subsequent sprints.
 */
package com.kbmiddleware.jaggaer;

package com.kbmiddleware.jaggaer.tracking;

import com.kbmiddleware.jaggaer.domain.TrackingEntry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

/**
 * Thread-safe in-memory {@link TrackingStore} for the Sprint 1 PoC.
 *
 * <p>Two maps are maintained:
 * <ul>
 *   <li>{@code byJaggaerId} &mdash; primary, drives idempotent create-or-get.</li>
 *   <li>{@code byRequestId} &mdash; secondary, supports GET lookup by Teamcenter request id.</li>
 * </ul>
 *
 * <p><b>Limitation</b>: state is lost on application restart. The interface contract
 * is preserved when the v1.0 implementation moves to a Teamcenter business object or
 * a JPA-backed table.
 */
@Slf4j
@Component
public class InMemoryTrackingStore implements TrackingStore {

    private final ConcurrentHashMap<String, TrackingEntry> byJaggaerId = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, TrackingEntry> byRequestId = new ConcurrentHashMap<>();

    @Override
    public StoreResult createOrGet(String jaggaerRequestId, Supplier<TrackingEntry> factory) {
        AtomicBoolean created = new AtomicBoolean(false);

        TrackingEntry entry = byJaggaerId.computeIfAbsent(jaggaerRequestId, key -> {
            TrackingEntry built = factory.get();
            byRequestId.put(built.getRequestId(), built);
            created.set(true);
            log.info("Created tracking entry requestId={} jaggaerRequestId={}",
                    built.getRequestId(), key);
            return built;
        });

        if (!created.get()) {
            log.info("Idempotent hit on jaggaerRequestId={} returning existing requestId={}",
                    jaggaerRequestId, entry.getRequestId());
        }
        return new StoreResult(entry, created.get());
    }

    @Override
    public Optional<TrackingEntry> findByRequestId(String requestId) {
        return Optional.ofNullable(byRequestId.get(requestId));
    }

    @Override
    public int size() {
        return byRequestId.size();
    }
}

package com.kbmiddleware.jaggaer.tracking;

import com.kbmiddleware.jaggaer.domain.TrackingEntry;

import java.util.Optional;
import java.util.function.Supplier;

/**
 * Persistence abstraction for {@link TrackingEntry} records.
 *
 * <p>Sprint 1 ships an in-memory implementation. The interface is the seam at which a
 * Teamcenter business object or JPA-backed implementation will plug in for v1.0.
 */
public interface TrackingStore {

    /**
     * Atomically returns the existing entry for {@code jaggaerRequestId} or invokes
     * {@code factory} once to create a new one.
     *
     * <p>The {@link StoreResult#created()} flag tells the caller whether the supplied
     * factory ran &mdash; this is how the controller knows whether to enqueue background
     * work or honour an idempotent re-submission.
     */
    StoreResult createOrGet(String jaggaerRequestId, Supplier<TrackingEntry> factory);

    /** Lookup by Teamcenter-generated request id (the GET path parameter). */
    Optional<TrackingEntry> findByRequestId(String requestId);

    /** Snapshot count of tracked requests (used by the health check). */
    int size();

    record StoreResult(TrackingEntry entry, boolean created) {}
}

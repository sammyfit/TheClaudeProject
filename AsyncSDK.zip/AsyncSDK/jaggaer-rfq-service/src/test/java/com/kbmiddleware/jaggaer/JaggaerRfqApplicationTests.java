package com.kbmiddleware.jaggaer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JaggaerRfqApplicationTests {

    @Test
    void contextLoads() {
        // Verifies the Spring application context starts cleanly with all beans wired.
    }
}

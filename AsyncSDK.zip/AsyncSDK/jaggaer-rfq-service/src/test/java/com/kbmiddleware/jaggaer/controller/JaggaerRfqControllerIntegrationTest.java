package com.kbmiddleware.jaggaer.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * End-to-end integration coverage for the JAGGAER RFQ controller.
 *
 * <p>Exercises every HTTP status code on the GET endpoint plus the POST happy path,
 * idempotency, validation, and the FAIL_TEST simulated-failure branch.
 *
 * <p>Simulator delays are forced to {@code PT0S} so the worker transitions through
 * every step within the same test method without sleeping.
 */
@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(properties = {
        "jaggaer.simulator.cvp-delay=PT0S",
        "jaggaer.simulator.master-data-delay=PT0S",
        "jaggaer.simulator.files-delay=PT0S",
        "jaggaer.simulator.package-delay=PT0S",
        "jaggaer.simulator.upload-delay=PT0S",
        "jaggaer.async.core-pool-size=2",
        "jaggaer.async.max-pool-size=2",
        "logging.level.com.kbmiddleware.jaggaer=INFO"
})
class JaggaerRfqControllerIntegrationTest {

    private static final String CREATE_PATH = "/cvsplmwebservices/sap/v1/kbCreateRfqDataPackage";
    private static final String GET_PATH    = "/cvsplmwebservices/sap/v1/kbGetRfqDataPackage/";
    private static final String HEALTH_PATH = "/cvsplmwebservices/sap/v1/healthCheck";

    @Autowired private MockMvc      mockMvc;
    @Autowired private ObjectMapper objectMapper;

    // -----------------------------------------------------------------------
    //  Health
    // -----------------------------------------------------------------------

    @Test
    void healthCheck_returnsUp() throws Exception {
        mockMvc.perform(get(HEALTH_PATH))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"))
                .andExpect(jsonPath("$.service").value("jaggaer-rfq-service"));
    }

    // -----------------------------------------------------------------------
    //  POST happy path
    // -----------------------------------------------------------------------

    @Test
    void post_validRequest_returns202WithRequestId() throws Exception {
        String body = """
                {
                  "jaggaerRequestId": "REQ-IT-001",
                  "requestorId":      "tester",
                  "partId":           "K211977",
                  "systemContext":    "TRUCK"
                }
                """;
        mockMvc.perform(post(CREATE_PATH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isAccepted())
                .andExpect(jsonPath("$.requestId").exists())
                .andExpect(jsonPath("$.jaggaerRequestId").value("REQ-IT-001"))
                .andExpect(jsonPath("$.status").value("ACCEPTED"))
                .andExpect(jsonPath("$.downloadUrl").exists())
                .andExpect(jsonPath("$.estimatedCompletion").exists());
    }

    @Test
    void post_duplicateJaggaerId_returnsSameRequestIdIdempotent() throws Exception {
        String body = """
                {
                  "jaggaerRequestId": "REQ-IT-IDEMPOTENT",
                  "requestorId":      "tester",
                  "partId":           "K1",
                  "systemContext":    "RAIL"
                }
                """;
        String first  = postAndReadRequestId(body);
        String second = postAndReadRequestId(body);
        assertThat(second).isEqualTo(first);
    }

    // -----------------------------------------------------------------------
    //  POST validation
    // -----------------------------------------------------------------------

    @Test
    void post_missingFields_returns400WithCode() throws Exception {
        mockMvc.perform(post(CREATE_PATH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("TC-400-VAL"));
    }

    @Test
    void post_malformedJson_returns400() throws Exception {
        mockMvc.perform(post(CREATE_PATH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{not-json"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("TC-400-VAL"));
    }

    // -----------------------------------------------------------------------
    //  GET — full status code matrix
    // -----------------------------------------------------------------------

    @Test
    void get_unknownRequestId_returns404() throws Exception {
        mockMvc.perform(get(GET_PATH + "tc-deadbeef"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("TC-404-REQ"));
    }

    @Test
    void get_whenReady_returns200WithZipBodyAndHeaders() throws Exception {
        String body = """
                {
                  "jaggaerRequestId": "REQ-IT-READY",
                  "requestorId":      "tester",
                  "partId":           "K2",
                  "systemContext":    "TRUCK"
                }
                """;
        String requestId = postAndReadRequestId(body);

        // Wait until the (zero-delay) worker reaches READY.
        await().atMost(5, TimeUnit.SECONDS).untilAsserted(() ->
                mockMvc.perform(get(GET_PATH + requestId))
                        .andExpect(status().isOk()));

        MvcResult result = mockMvc.perform(get(GET_PATH + requestId))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/zip"))
                .andExpect(header().exists("X-Package-Request-Id"))
                .andExpect(header().exists("X-Package-Jaggaer-Request-Id"))
                .andExpect(header().string("X-Package-Split-Count", "1"))
                .andExpect(header().string("X-Package-Part-Index", "1"))
                .andReturn();

        // Verify the body is a valid ZIP containing README.txt.
        byte[] zip = result.getResponse().getContentAsByteArray();
        assertThat(zip).isNotEmpty();
        try (ZipInputStream zis = new ZipInputStream(new java.io.ByteArrayInputStream(zip))) {
            ZipEntry entry = zis.getNextEntry();
            assertThat(entry).isNotNull();
            assertThat(entry.getName()).isEqualTo("README.txt");
        }
    }

    @Test
    void get_whenFailTriggered_returns410WithCvpError() throws Exception {
        String body = """
                {
                  "jaggaerRequestId": "REQ-IT-FAIL",
                  "requestorId":      "tester",
                  "partId":           "FAIL_TEST",
                  "systemContext":    "TRUCK"
                }
                """;
        String requestId = postAndReadRequestId(body);

        await().atMost(5, TimeUnit.SECONDS).untilAsserted(() ->
                mockMvc.perform(get(GET_PATH + requestId))
                        .andExpect(status().isGone()));

        mockMvc.perform(get(GET_PATH + requestId))
                .andExpect(status().isGone())
                .andExpect(jsonPath("$.state").value("FAILED"))
                .andExpect(jsonPath("$.error.code").value("TC-404-CVP"))
                .andExpect(jsonPath("$.error.message").value("Part number not valid"));
    }

    // -----------------------------------------------------------------------
    //  Helpers
    // -----------------------------------------------------------------------

    private String postAndReadRequestId(String body) throws Exception {
        MvcResult result = mockMvc.perform(post(CREATE_PATH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isAccepted())
                .andReturn();
        JsonNode node = objectMapper.readTree(result.getResponse().getContentAsString());
        return node.get("requestId").asText();
    }
}
